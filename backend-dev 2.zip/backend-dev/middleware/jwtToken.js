import jwt from 'jsonwebtoken';
import dotenv  from "dotenv"

dotenv.config()

export const  generateAccessToken= (user) => {
    try {
        return jwt.sign(user, process.env.jwtTokenSecret,
            //  { expiresIn: '1800s' },
            );
    } catch (error) {
        return error }  
    };

 export const authenticateJWT = (req, res, next) => {
    try {
        const jwtToken = req.headers.token;
        // console.log(jwtToken)
        if (jwtToken) {
            jwt.verify(jwtToken, process.env.jwtTokenSecret, (err, user) => {
                if (err) {
                    return res.status(500).json({errorMessage:"Internal error", error:err});
                }
                req.user = user;
                next();
            });
        } else {
            return res.status(401).json({error:"Unauthorized!!", errorMessage:" Token missing!"});
        }
    } catch (error) {
        return res.status(400).json({ msg: "failure", error:error });
    }
};