import { z } from 'zod';

const environmentEnum = ["dev", "prod"];
const statusEnum = ["raised", "closed"];
const yesNoEnum = ['yes','no'];
const stageEnum = ["approvalPending", "pendingWithMaker"];


export const createTicketSchema = z.object({
    ticket_id: z
    .string()
    .min(5),
    title: z
    .string()
    .min(8,{ message: "Must be 5 or more characters long" })
    .max(50,({ message: "Must be 50 or fewer characters long" })),
    maker_name: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(50,{message: "Must be 50 or fewer characters long"}),
    pm_name: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(50,{message: "Must be 50 or fewer characters long"}),
    environment: z
    .enum(environmentEnum),
    status: z
    .enum(statusEnum),
    stage: z
    .enum(stageEnum),
   
    checker_name: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(50,{message: "Must be 50 or fewer characters long"}),
    isChecked: z.enum(yesNoEnum),
    // chekedOn: z.string().datetime({ local: true }),

    approver: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(50,{message: "Must be 50 or fewer characters long"}),
    isApproved: z.enum(yesNoEnum),
    // approvedOn: z.string().datetime({ local: true }),

    isImplemented: z.enum(yesNoEnum),
    // implementedOn: z.string().datetime({ local: true })
});



