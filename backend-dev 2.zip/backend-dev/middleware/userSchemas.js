import { z } from 'zod';

const trunFalseEnum = ["true", "false"];

export const createUserSchema = z.object({
  email: z
    .string()
    .email({ message: "Invalid email address!!" }),
  password: z
    .string()
    .min(8,{ message: "Must be 5 or more characters long" })
    .max(20,({ message: "Must be 20 or fewer characters long" })),
  name: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(70,{message: "Must be 50 or fewer characters long"}),
    
    isMaker: z.enum(trunFalseEnum),
    isChecker: z.enum(trunFalseEnum),
    isApprover: z.enum(trunFalseEnum),
    isImplementer_CFG: z.enum(trunFalseEnum),
    isImplementer_DBA: z.enum(trunFalseEnum),
    isImplementer_WIN: z.enum(trunFalseEnum),
    isAdmin: z.enum(trunFalseEnum),    
});

export const userLoginSchema = z.object({
  email: z.string().email(),
  password: z.string()
});


