import Users from "../models/users.js";
// import { validationResult } from "express-validator";

import { generateAccessToken } from "../middleware/jwtToken.js";

import dotenv  from "dotenv"

dotenv.config()


export const createUser = async (req, resp, next) => {
  //perfrom data validation
  try {
    
    // //if validation errors are success then processed else return
    // const errors = validationResult(req);
    // // console.log("ERROR -------------------",  errors.array());
    // if (!errors.isEmpty()) {
    //   console.log(errors.array());
    //   return resp.status(422).json(errors);
    // }

    const data = req.body;
    const result = await Users.create({ ...data },process.env.jwtTokenSecret);
    if (result) {
      return resp.status(201).json({ msg: "user created successfully!!" });
    }
  } catch (error) {
    console.log('ERROR ----',error);
    return resp.status(400).json({ msg: "failure", error:error.errors[0] });
  }
 
};

export const loginUser = async (req, resp, next) => {
try {

    // //if validation errors are success then processed else return
    // const errors = validationResult(req);
    // // console.log("ERROR -------------------",  errors.array());
    // if (!errors.isEmpty()) {
    //   console.log(errors.array());
    //   return resp.status(422).json(errors);
    // }

  const data = req.body;
  const email = req.body.email;
  const pass = req.body.password;

  const user = await Users.findByPk(email);
  if (user) {
    if (user.password === pass) {
      const usr = { ...user.dataValues };
      delete usr.password;
      const token = generateAccessToken(usr)
        return resp.status(200).json({ message: "User logged in successfully!!", token: token });
    } else {
      return resp.status(400).json({ msg: "Invalid password" });
    }
  } 
  else {
    return resp.status(404).json({ msg: "User not found" });
    }
  } 
catch (error) {
    return resp.status(400).json({ msg: "failure", error:error.errors[0] });
  }
};
