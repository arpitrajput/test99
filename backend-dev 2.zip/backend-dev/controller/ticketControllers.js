import ticketMaster from "../models/ticketMaster.js";
import jwt from "jsonwebtoken";
import { validationResult } from "express-validator";


export const createTicket = async (req, resp, next) => {
  //perfrom data validation
  try {
    
    // const errors = validationResult(req);
    // console.log("ERROR -------------------",  errors.array());
    // if (!errors.isEmpty()) {
    //   console.log(errors.array());
    //   return resp.status(422).json(errors);
    // }


    const data = req.body;
    const result = await ticketMaster.create({ ...data });
    if (result) {
      return resp.status(201).json({ msg: "Ticket created successfully!!" });
    }
  } catch (error) {
    // console.log('ERROR ----',error);
    return resp.status(400).json({ msg: "failure", error:error });
  }
};



export const amendTicket = async (req, resp, next) => {

  const ticket_id = req.body.ticket_id;



  let columns = ["title", "pm_name","environment"] 

    var x;
  for (let c of columns) {
      if (c in req.body) { 
        x = columns[c] = req.body[c]
        console.log(columns.columns[c]=req.body[c])

      }
  }

  // return resp.status(400).json({ msg: "failure" ,ticket_id:ticket_id,updateValues:updateValues});

 
};



export const fetchTickets = async (req, resp, next) => {
  //perfrom data validation
  try {
    const data = req.body;
    console.log(data)

    const result = await ticketMaster.findAll();
    if (result) {
      return resp.status(201).json({ tickets:result });
    }
  } catch (error) {
    console.log('ERROR ----',error);
    return resp.status(400).json({ msg: "failure", error:error });
  }
};
