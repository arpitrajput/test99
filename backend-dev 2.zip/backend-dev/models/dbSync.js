import Users from "./users.js";
import ticketMaster from "./ticketMaster.js";


export const syncDB = () => {
  Users.sync();
  ticketMaster.sync();
};