import { Router } from "express";
import { createTicket, fetchTickets,amendTicket } from "../controller/ticketControllers.js";
import { validateData } from '../middleware/validationMiddleware.js';
import { createTicketSchema} from '../middleware/ticketSchema.js';

import { authenticateJWT } from "../middleware/jwtToken.js";

const router = Router();

router.post("/create", validateData(createTicketSchema), authenticateJWT, createTicket);

router.post("/amend", amendTicket);


router.post("/fetch", authenticateJWT, fetchTickets);



export default router;



