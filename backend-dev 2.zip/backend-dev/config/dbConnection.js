import { Sequelize } from "sequelize";

import dotenv  from "dotenv"

dotenv.config()
// const dbName = process.env.databaseName;
// const username = process.env.username
// const password = process.env.password;
// const dbHost = process.env.dbHost;


const dbName = 'deploy_desk';
const username = 'root';
const password = 'password';
const dbHost = 'localhost';



// let a = `mysql://${username}:${password}@${dbHost}/${dbName}`
// console.log("log---",a);

console.log()
const sequelize = new Sequelize(
  `mysql://${username}:${password}@${dbHost}/${dbName}`
);

try {
  await sequelize.authenticate();
  console.log("connected successfully");
} catch (err) {
  console.log(err);
}

export default sequelize;
