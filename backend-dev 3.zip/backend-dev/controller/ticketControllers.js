import ticketMaster from "../models/ticketMaster.js";
import jwt from "jsonwebtoken";
import {
  validationResult
} from "express-validator";
import BarDeployment from "../models/BarDeployment.js";
import Cache from "../models/Cache.js"
import Other from "../models/OtherDeploymentDetails.js";
import Ticket from "../models/Ticket.js";
import URLConfig from "../models/UrlConfig.js";
import StageTracker from "../models/StageTracker.js";


export const createTicket = async (req, resp, next) => {
  // console.log('create ticket')
  let StageTrackerData=null
  try {
    {
      const payload = req.body;
      const ticketDetails = payload.ticketDetails;
      const deploymentDetails = payload.deploymentDetails;
      const result = await Ticket.create({
        ...ticketDetails,
        createdBy: "323232",
      });
      console.log(result);
      const ticketID = result.dataValues.ticketID;

      switch (ticketDetails.deployment_type) {
        case "BAR":
          for (let i = 0; i < deploymentDetails.length; i++) {
            let cacheResult,urlConfigResult
            const barResult = await BarDeployment.create({
              ...deploymentDetails[i],
              ticketID: ticketID,
            });
            if (Object.keys(deploymentDetails[i]).includes("cache")&&deploymentDetails[i].cache) {
              cacheResult=await Cache.create({
                cache: deploymentDetails[i].cache,
                ticketID: ticketID,
                barDeploymentID: barResult.dataValues.barDeploymentID,
              });
            }
            if (Object.keys(deploymentDetails[i]).includes("urlConfig")&&deploymentDetails[i].urlConfig) {
              urlConfigResult=await URLConfig.create({
                urlConfig: deploymentDetails[i].urlConfig,
                ticketID: ticketID,
                barDeploymentID: barResult.dataValues.barDeploymentID,
              });
            }
             StageTrackerData={
              ticketID:ticketID,
              barDeploymentID:barResult.dataValues.barDeploymentID,
              cacheID:cacheResult?.dataValues.cacheID,
              urlConfigID:urlConfigResult?.dataValues.urlConfigID,
              checker:ticketDetails["pm_name"],
              stage:"Pending with Checker"
            }
            await StageTracker.create(StageTrackerData)
          }

          break;
        case "URL":
          const urlConfigResult=await URLConfig.create({
            ...deploymentDetails,
            ticketID: ticketID,
          });
           StageTrackerData={
            ticketID:ticketID,
            urlConfigID:urlConfigResult.dataValues.urlConfigID,
            checker:ticketDetails["pm_name"],
            stage:"Pending with Checker"
            }
            await StageTracker.create(StageTrackerData)
          
          break;

        case "CACHE":
          const cacheResult=await Cache.create({
            ...deploymentDetails,
            ticketID: ticketID,
          });
          StageTrackerData={
            ticketID:ticketID,
            cacheID:cacheResult.dataValues.cacheID,
            checker:ticketDetails["pm_name"],
            stage:"Pending with Checker"
            }
            await StageTracker.create({...StageTrackerData})
          break;

        case "OTHER":
          const otherResult=await Other.create({
            ...deploymentDetails,
            ticketID: ticketID,
          });
          StageTrackerData={
            ticketID:ticketID,
            otherID:otherResult.dataValues.otherID,
            checker:ticketDetails["pm_name"],
            stage:"Pending with Checker"
            }
            await StageTracker.create(StageTrackerData)
          break;

        case "CACHE_URL":
          const cacheID=await Cache.create({
            ...deploymentDetails,
            ticketID: ticketID,
          });
          const urlConfigID=await URLConfig.create({
            ...deploymentDetails,
            ticketID: ticketID,
          });
          StageTrackerData={
            ticketID:ticketID,
            cacheID:cacheID.dataValues.cacheID,
            urlConfigID:urlConfigID.dataValues.urlConfigID,
            checker:ticketDetails["pm_name"],
            stage:"Pending with Checker"
            }
            await StageTracker.create(StageTrackerData)
          break;
      }

      return resp
        .status(201)
        .json({
          ticketID: ticketID,
          msg: "Ticket created successfully!!"
        });
    };

  } catch (error) {
    // console.log('ERROR ----',error);
    return resp.status(400).json({
      msg: "failure",
      error: error
    });
  }

  // //perfrom data validation
  // try {

  //   const data = req.body;
  //   const result = await ticketMaster.create({ ...data });
  //   if (result) {
  //     return resp.status(201).json({ msg: "Ticket created successfully!!" });
  //   }
  // } catch (error) {
  //   // console.log('ERROR ----',error);
  //   return resp.status(400).json({ msg: "failure", error:error });
  // }
};



export const amendTicket = async (req, resp, next) => {

  const ticket_id = req.body.ticket_id;



  let columns = ["title", "pm_name", "environment"]

  var x;
  for (let c of columns) {
    if (c in req.body) {
      x = columns[c] = req.body[c]
      console.log(columns.columns[c] = req.body[c])

    }
  }

  // return resp.status(400).json({ msg: "failure" ,ticket_id:ticket_id,updateValues:updateValues});


};



export const fetchTickets = async (req, resp, next) => {
  //perfrom data validation
  try {
    const resultIdData = await StageTracker.findAll({
      attributes: ['barDeploymentID', 'cacheID','urlConfigID','otherID'],
      where: {
        ticketID: req.body.ticketID,
      }
    })

    let ticketData = {};
    ticketData = await Ticket.findByPk(req.body.ticketID)

    let subData = [];
      for (let i=0;i<resultIdData.length;i++)
    {
      let barData, cacheData, urlData,otherData;
      if (resultIdData[i].barDeploymentID){
        barData = await BarDeployment.findByPk(resultIdData[i].barDeploymentID)}

      if (resultIdData[i].cacheID){
        cacheData = await Cache.findByPk(resultIdData[i].cacheID)}

      if (resultIdData[i].urlConfigID){
        urlData = await URLConfig.findByPk(resultIdData[i].urlConfigID)}

      if (resultIdData[i].otherID){
        otherData = await Other.findByPk(resultIdData[i].otherID)}

      if(barData){
        subData[i]={...barData.dataValues}
      }
      if(cacheData){
        subData[i]={...subData[i],...cacheData.dataValues}
      }
      if(urlData){
        subData[i]={...subData[i],...urlData.dataValues}
      }
        if(otherData){
      subData.push(otherData)
        }
    }
    if (ticketData) {
      return resp.status(201).json({
        tickets: ticketData.dataValues,
        deploymentDetails:subData
      });
    }
  } catch (error) {
    console.log('ERROR ----', error);
    return resp.status(400).json({
      msg: "failure",
      error: error
    });
  }
};