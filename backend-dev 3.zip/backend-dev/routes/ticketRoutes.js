import { Router } from "express";
import { createTicket, fetchTickets,amendTicket } from "../controller/ticketControllers.js";
import { validateData } from '../middleware/validationMiddleware.js';
import { createTicketSchema} from '../middleware/ticketSchema.js';
import {ticketSchema} from '../middleware/ticketSchemaa.js'

import { authenticateJWT } from "../middleware/jwtToken.js";

const router = Router();


// router.post("/create", validateData(createTicketSchema), authenticateJWT, createTicket);

router.post("/create", createTicket);

router.post("/amend", amendTicket);


router.post("/fetch", fetchTickets);



export default router;



