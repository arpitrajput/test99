import { Router } from "express";
import { createUser, loginUser } from "../controller/usersController.js";
import { validateData } from '../middleware/validationMiddleware.js';
import { userLoginSchema, createUserSchema } from '../middleware/userSchemas.js';

import {authenticateJWT} from '../middleware/jwtToken.js'

const router = Router();

router.post("/create",createUser);
router.post("/login", validateData(userLoginSchema),loginUser);

export default router;



