import { DataTypes, Model } from "sequelize";
import sequelize from "../config/dbConnection.js";

class ticketMaster extends Model {}

ticketMaster.init(
  {
    ticket_id: { 
        type: DataTypes.BIGINT, 
        primaryKey: true 
    },
    title: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    maker_name: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    pm_name: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    environment: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    status: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    stage: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    checker_name: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    isChecked: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    chekedOn: { 
        type: DataTypes.DATE, 
        defaultValue: DataTypes.NOW,
    },
    approver: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    isApproved: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    approvedOn: { 
        type: DataTypes.DATE, 
        defaultValue: DataTypes.NOW,
    },
    isImplemented: { 
        type: DataTypes.STRING, 
        allowNull:false
    },
    implementedOn: { 
        type: DataTypes.DATE, 
        defaultValue: DataTypes.NOW,
    },
},
    {
        sequelize: sequelize,
        modelName: "Ticket_Master",
        freezeTableName: true,
    }
);

export default ticketMaster;
