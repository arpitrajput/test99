import { DataTypes, Model, UUIDV1 } from "sequelize";
import sequelize from "../config/dbConnection.js";
import Ticket from "./Ticket.js";
import { v1 } from "uuid";

class BarDeployment extends Model {}

BarDeployment.init(
  {
    barDeploymentID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement:true
    },
    ticketID: {
      type: DataTypes.INTEGER,
      references: {
        model: Ticket,
        key: "ticketID",
      },
      allowNull: false,
      onUpdate: "CASCADE",
      onDelete: "CASCADE",
    },
    name: { type: DataTypes.STRING, allowNull: false },
    url: { type: DataTypes.STRING, allowNull: false },
    barPath: { type: DataTypes.STRING, allowNull: false },
    newOrExisting: { type: DataTypes.STRING, allowNull: false },
    serverType: { type: DataTypes.STRING, allowNull: false },
    sourceCodePath: { type: DataTypes.STRING, allowNull: false },
    broker: { type: DataTypes.STRING, allowNull: false },
    eg: { type: DataTypes.STRING, allowNull: false },
    certificatePath: { type: DataTypes.STRING, allowNull: false },
  },
  {
    sequelize: sequelize,
    modelName: "Bar_Deployment_Master",
    freezeTableName: true,
  }
);

export default BarDeployment;
