import { DataTypes, Model } from "sequelize";
import sequelize from "../config/dbConnection.js";
import Ticket from "./Ticket.js";
import { v1 } from "uuid";

class Other extends Model {}

Other.init(
  {
    otherID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement:true,
    },
    ticketID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: Ticket, key: "ticketID" },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
    other: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    sequelize: sequelize,
    modelName: "Other_Master",
    freezeTableName: true,
  }
);

export default Other;
