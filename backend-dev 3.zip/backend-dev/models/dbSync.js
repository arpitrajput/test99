import Users from "./users.js";
import ticketMaster from "./ticketMaster.js";
import BarDeployment from "./BarDeployment.js";
import Cache from "./Cache.js";
import Other from "./OtherDeploymentDetails.js";
import Ticket from "./Ticket.js";
import URLConfig from "./UrlConfig.js";
import StageTracker from "./StageTracker.js";



export const syncDB = () => {
  // ticketMaster.sync();
  Users.sync({force:false});
  Ticket.sync({force:false});
  BarDeployment.sync({force:false});
  Cache.sync({force:false});
  URLConfig.sync({force:false});
  Other.sync({force:false});
  StageTracker.sync({force:false})
};