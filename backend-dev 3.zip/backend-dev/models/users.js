import { DataTypes, Model } from "sequelize";
import sequelize from "../config/dbConnection.js";


class Users extends Model {}

Users.init(
  {
    email: { type: DataTypes.STRING, primaryKey: true },
    password: { type: DataTypes.STRING, allowNull: false },
    name: { type: DataTypes.STRING, allowNull: false,},
    adID:{type:DataTypes.STRING,allowNull:false},
    isMaker: { type: DataTypes.BOOLEAN, allowNull: false},
    isChecker: { type: DataTypes.BOOLEAN, defaultValue: false },
    isApprover: { type: DataTypes.BOOLEAN, defaultValue: false },
    isImplementer_CFG: { type: DataTypes.BOOLEAN, defaultValue: false },
    isImplementer_DBA: { type: DataTypes.BOOLEAN, defaultValue: false },
    isImplementer_WIN: { type: DataTypes.BOOLEAN, defaultValue: false },
    isAdmin: { type: DataTypes.BOOLEAN, defaultValue: false },
  },
  {
    sequelize: sequelize,
    modelName: "User_Master",
    freezeTableName: true,
  }
);

export default Users;







// Users.init(
//   {
//     email: { type: DataTypes.STRING, primaryKey: true },
//     password: { type: DataTypes.STRING, allowNull: false },
//     name: { type: DataTypes.STRING, allowNull: false,validate: {
//       notNull: {
//         msg: 'Please enter your name',
//       } }},
//     isMaker: { type: DataTypes.BOOLEAN, allowNull: false,validate: {
//       notNull: {
//         msg: 'Please enter role',
//       } } },
//     isChecker: { type: DataTypes.BOOLEAN, defaultValue: false },
//     isApprover: { type: DataTypes.BOOLEAN, defaultValue: false },
//     isImplementer_CFG: { type: DataTypes.BOOLEAN, defaultValue: false },
//     isImplementer_DBA: { type: DataTypes.BOOLEAN, defaultValue: false },
//     isImplementer_WIN: { type: DataTypes.BOOLEAN, defaultValue: false },
//     isAdmin: { type: DataTypes.BOOLEAN, defaultValue: false },
//   },
//   {
//     sequelize: sequelize,
//     modelName: "User_Master",
//     freezeTableName: true,
//   }
// );