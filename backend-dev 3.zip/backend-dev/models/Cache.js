import { DataTypes, Model } from "sequelize";
import sequelize from "../config/dbConnection.js";
import Ticket from "./Ticket.js";
import BarDeployment from "./BarDeployment.js";
import { v1 } from "uuid";

class Cache extends Model {}

Cache.init(
  {
    cacheID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement:true,
    },
    ticketID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: Ticket, key: "ticketID" },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
    barDeploymentID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: { model: BarDeployment, key: "barDeploymentID" },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
    cache: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    sequelize: sequelize,
    modelName: "Cache_Master",
    freezeTableName: true,
  }
);

export default Cache;
