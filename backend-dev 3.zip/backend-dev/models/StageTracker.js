import { DataTypes, Model } from "sequelize";
import sequelize from "../config/dbConnection.js";
import Ticket from "./Ticket.js";
import BarDeployment from "./BarDeployment.js";
import Cache from "./Cache.js";
import URLConfig from "./UrlConfig.js";
import Other from "./OtherDeploymentDetails.js";
import Users from "./users.js";

class StageTracker extends Model{}

StageTracker.init({
    ticketID:{
        type:DataTypes.INTEGER,
        references:{
            model:Ticket,
            key:"ticketID"
        },
        allowNull:false,
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    barDeploymentID:{
        type:DataTypes.INTEGER,
        references:{
            model:BarDeployment,
            key:"barDeploymentID"
        },
        allowNull:true,
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    cacheID:{
        type:DataTypes.INTEGER,
        references:{
            model:Cache,
            key:"cacheID"
        },
        allowNull:true,
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    urlConfigID:{
        type:DataTypes.INTEGER,
        references:{
            model:URLConfig,
            key:"urlConfigID"
        },
        allowNull:true,
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    otherID:{
        type:DataTypes.INTEGER,
        references:{
            model:Other,
            key:"otherID"
        },
        allowNull:true,
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    checker:{
        type:DataTypes.STRING,
        allowNull:false
    },
    isChecked:{
        type:DataTypes.BOOLEAN, defaultValue:false
        
    },
    checkedBy:{
        type:DataTypes.STRING
    },
    checkedAt:{
        type:DataTypes.STRING
    },
    isApproved:{
        type:DataTypes.BOOLEAN, defaultValue:false
    },
    approvedBy:{
        type:DataTypes.STRING,
        references:{
            model:Users,
            key:"email"
        },
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    approvedAt:{
        type:DataTypes.STRING
    },
    stage:{
        type:DataTypes.STRING
    },
    isBarDeployed:{
        type:DataTypes.BOOLEAN, defaultValue:false
    },
    barDeployedAt:{
        type:DataTypes.STRING
    },
    barDeployedBy:{
        type:DataTypes.STRING,
        references:{
            model:Users,
            key:"email"
        },
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    isCacheDeployed:{
        type:DataTypes.BOOLEAN, defaultValue:false
    },
    cacheDeployedAt:{
        type:DataTypes.STRING
    },
    cacheDeployedBy:{
        type:DataTypes.STRING,
        references:{
            model:Users,
            key:"email"
        },
        
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
    isurlConfigDeployed:{
        type:DataTypes.BOOLEAN, defaultValue:false
    },
    urlConfigDeployedAt:{
        type:DataTypes.STRING
    },
    urlConfigDeployedBy:{
        type:DataTypes.STRING,
        references:{
            model:Users,
            key:"email"
        },
        onUpdate:"CASCADE",
        onDelete:"CASCADE"
    },
},{
    
        sequelize: sequelize,
        modelName: "Stage_Tracker",
        freezeTableName: true,
      
})

export default StageTracker