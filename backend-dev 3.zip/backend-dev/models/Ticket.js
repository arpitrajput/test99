import { DataTypes, Model } from "sequelize";
import sequelize from "../config/dbConnection.js";

class Ticket extends Model {}

Ticket.init(
  {
    ticketID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      validate: {
        min: {
          args: 10000,
          msg: "Value must be atleast 10000",
        },
      },
    },
    title: { type: DataTypes.STRING, allowNull: false },
    pm_name: { type: DataTypes.STRING, allowNull: false },
    env: { type: DataTypes.STRING, allowNull: false },
    demand_details: { type: DataTypes.STRING, allowNull: false },
    tfs_cr: { type: DataTypes.INTEGER, allowNull: false },
    deployment_type: { type: DataTypes.STRING, allowNull: false },
    createdBy: { type: DataTypes.STRING, allowNull: false },
  },
  {
    sequelize: sequelize,
    modelName: "Ticket_Master",
    freezeTableName: true,
  }
);

export default Ticket;
