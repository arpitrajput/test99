import { ZodError } from "zod"

import { StatusCodes } from "http-status-codes"

export function validateData(schema) {
  return (req, res, next) => {
    try {
      schema.parse(req.body.ticketDetails)
      next()
    } catch (error) {
      if (error instanceof ZodError) {
        const errorMessages = error.errors.map(issue => ({
          // message: [`Field_Name:${issue.path.join(".")}`, `Error_Message:${issue.path,issue.message}`]
          message: [`field Name: ${issue.path.join(".")}`, `Error_Message:${issue.path.join(".")} is ${issue.path,issue.message}`]
        }))
        console.log(error)
        res
          .status(StatusCodes.BAD_REQUEST)
          .json({ error: "Invalid data", details: error })
      } else {
        res 
          .status(StatusCodes.INTERNAL_SERVER_ERROR)
          .json({ error: "Internal Server Error" })
      }
    }
  }
}
