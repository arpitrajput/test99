import { z } from 'zod';

const environmentEnum = ["ST", "UAT","Pre-Prod"];
const deploymentTypeEnum = ["Bar Deployment", "CACHE","URL Configuration", "Cache and URL Configuration","Other Request"];

const statusEnum = ["raised", "closed"];
const yesNoEnum = ['yes','no'];
const stageEnum = ["approvalPending", "pendingWithMaker"];


export const ticketSchema = z.object({
    title: z
    .string()
    .min(8,{ message: "Must be 8 or more characters long" })
    .max(100,({ message: "Must be 100 or fewer characters long" })),
    pm_name: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(50,{message: "Must be 50 or fewer characters long"}),
    environment: z
    .enum(["ST", "UAT","Pre-Prod"], {message:"Values isn't allowed"}),   
    demand_details: z
    .string()
    .min(3,{ message: "Must be 3 or more characters long" })
    .max(50,{message: "Must be 50 or fewer characters long"}),
    // tfs_cr: z
    // // .bigint({message:'only Integer value is allowed'})
    // .lte(100000, { message: "Number is too big !!" }),
    deployment_type:z
    .enum(deploymentTypeEnum,{message:"Value isn't not allowed"}),
});



