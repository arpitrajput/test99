import express from "express";
import cors from "cors";
import { syncDB } from "./models/dbSync.js";
import userRouter from "./routes/usersRoutes.js";
import ticketRouter from "./routes/ticketRoutes.js";
import dotenv  from "dotenv"

dotenv.config()


const PORT = process.env.PORT || 5001;
const app = express();
const jsonParser = express.json({ limit: "10mb" });

app.use(jsonParser);
app.use(cors());

app.get("/", (req, resp) => {
  return resp.status(200).json({ Connected: "GET API successfully" });
});

app.use("/user", userRouter);
app.use("/ticket", ticketRouter);


syncDB();

app.listen(PORT, "0.0.0.0",(err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("Server listning on port ", PORT);
  }
});
